<?php
// including the database connection file
include_once("config.php");
 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    
    $nazev=$_POST['nazev'];
    $text=$_POST['text'];
 $autor=$_POST['autor'];
    
    // checking empty fields
    if(empty($nazev) || empty($autor) || empty($text)) {
        if(empty($nazev)) {
            echo "<font color='red'>Pole je prázdné.</font><br/>";
        }
        
        if(empty($autor)) {
            echo "<font color='red'>Pole je prázdné.</font><br/>";
        }     
 if(empty($text)) {
            echo "<font color='red'>Pole je prázdné.</font><br/>";
        }      
    } else {    
        //updating the table
        $result = mysqli_query($mysqli, "UPDATE clanky SET nazev='$nazev'text='$text'autor='$autor' WHERE id=$id");
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: index.php");
    }
}
?>
<?php
//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM clanky WHERE id=$id");
 
while($res = mysqli_fetch_array($result))
{
    $nazev = $res['nazev'];
    $text = $res['text'];
    $autor=$_POST['autor'];
}
?>
<html>
<head>    
    <title>Edit Data</title>
</head>
 
<body>
    <a href="index.php">Home</a>
    <br/><br/>
    
    <form name="form1" method="post" action="edit.php">
        <table border="0">
            <tr> 
                <td>Název</td>
                <td><input type="text" name="nazev" value="<?php echo $nazev;?>"></td>
            </tr>
            <tr> 
                <td>Text</td>
                <td><input type="text" name="text" value="<?php echo $text;?>"></td>
            </tr>
		<tr> 
                <td>Text</td>
                <td><input type="text" name="autor" value="<?php echo $text;?>"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>