<?php
include ("../auth.php");
?>
<html>
<head>    
  <html lang="cs">
</head>
 
<body>
   <html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>RSP Gumaci</title>
</head>

<style type="text/css">
    .item{
      width: 100%;
      height: 90vh;
    }
    .text-center{
        margin-top: 20px;
    }
    #tabulka{
        margin-top: 50px;
        width: 80%;
    }
    #nahoru{
        text-align: center;
    }
</style>

<body>
<nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="RSP_Gumaci_dokumentace.docx">GUMÁCI VSPJ</a>
          </div>
          <ul class="nav navbar-nav">
            <li class=""><a href="#">ÚVOD</a></li>
            <li><a href="index.php">ČLÁNKY</a></li>
            <li><a href="../../kontakt.html">KONTAKT</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
           <li><a><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['username']; ?></a></li>
              <li><a href="../logout.php"><span class="glyphicon glyphicon-log-in"></span> Odhlášení</a></li>
          </ul>
        </div>
      </nav> 
 
 

    
    
 
    <form action="add.php" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td>Název</td>
                <td><input type="text" name="nazev"></td>
            </tr>
            <tr> 
                <td>Autor</td>
                <td><input type="text" name="autor"></td>
            </tr>
		<tr> 
                <td>Text</td>
                <td><input type="text" name="text"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
        </table>
    </form>
</body>
</html>