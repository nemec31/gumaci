<html>
<head>
    <title>Add Data</title>
</head>
 
<body>
<?php
//including the database connection file
include_once("config.php");
 
if(isset($_POST['Submit'])) {    
    $nazev = $_POST['nazev'];
    $text = $_POST['text'];
        
    // checking empty fields
    if(empty($nazev) ||  empty($text)) {
        if(empty($$nazev)) {
            echo "<font color='red'>Pole je prázdné.</font><br/>";
        }

        if(empty($text)) {
            echo "<font color='red'>Pole je prázdné.</font><br/>";
        }
        
        //link to the previous page
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    } else { 
        // if all the fields are filled (not empty)             
        //insert data to database
        $result = mysqli_query($mysqli, "INSERT INTO clanky(nazev,text) VALUES('$nazev','$text')");
        
        //display success message
        echo "<font color='green'>Data added successfully.";
        echo "<br/><a href='index.php'>View Result</a>";
    }
}
?>
</body>
</html>