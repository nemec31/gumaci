<?php
// Initialize the session
session_start();

 if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
kill;
}
   else
{
  header("location: ../login.php");
exit();

}

include("auth.php");
// Include config file
require_once "config.php";
 ?>
<html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>RSP Gumaci</title>
</head>

<style type="text/css">
    .item{
      width: 100%;
      height: 90vh;
    }
    .text-center{
        margin-top: 20px;
    }
    #tabulka{
        margin-top: 50px;
        width: 80%;
    }
    #nahoru{
        text-align: center;
    }
</style>

<body>
    
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="../RSP_Gumaci_dokumentace.docx">GUMÁCI VSPJ</a>
          </div>
          <ul class="nav navbar-nav">
            <li class=""><a href="index.php">ÚVOD</a></li>
            <li><a href="clanky/index.php">ČLÁNKY</a></li>
            <li><a href="kontakt.php">KONTAKT</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
           <li><a><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['username']; ?></a></li>
              <li><a href="../logout.php"><span class="glyphicon glyphicon-log-in"></span> Odhlášení</a></li>
          </ul>
        </div>
      </nav> 


      <div class="container-fluid" id="carouselFull">
        
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
          <!-- Indicators -->
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
          </ol>
      
          <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <div class="item active">
              <img src="obr1.jpg"  style="width:100%;">
            </div>
      
            <div class="item">
              <img src="obr2.jpg"  style="width:100%;">
            </div>
          
            <div class="item">
              <img src="obr3.jpg"  style="width:100%;">
            </div>
          </div>
      
          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Předchozí</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Další</span>
          </a>
        </div>
      </div>

      <div class="row text-center">
        <div class="col-sm-4"><h3>Tým:</h3><br><img class="img-circle" src="logoG.svg" width="200px" alt="photo"></div>
        <div class="col-sm-4"><h3>Něco o nás: </h3><p> Jsme Tým který se pokouší udělat webovou aplikaci, ktéra má fungovat ve stylu školního časopisu. </p></div>
            <div class="dropdown">
          </div></div>
      </div> 

      <div class="container" id="tabulka">
          <h2>Zaměstnanci</h2>
        <table class="table table-hover table-striped">
            <thead class="thead-dark">
              <tr>
                <th>Funkce</th>
                <th>Pozice</th>
                <th>Email</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Admin</td>
                <td>Administrator</td>
                <td>AdministratorGumaci@google.com</td>
              </tr>
              <tr>
                <td>Autor článků</td>
                <td>Autor</td>
                <td>AutorGumaci@google.com</td>
              </tr>
              <tr>
                <td>Uzivatel</td>
                <td>User</td>
                <td>UserGumaci@google.com</td>
              </tr>
            </tbody>
          </table>
      </div>

      <div class="container" id="nahoru"><button onclick="window.location.href='#'" class="btn btn-warning">Nahoru</button></div>
      <div class="container-fluid">
        <footer class="text-right">
            <a href="#" data-toggle="tooltip" title="Tvůrce!">&copy; Gumáci 2020</a>
        </footer>    
      </div>
      <script>
        $(document).ready(function(){
            $('[data-toggle="popover"]').popover(); 
            $('[data-toggle="tooltip"]').tooltip();     
        });
        </script>
</body>
</html>