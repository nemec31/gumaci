<html>
<head>
    <title>Add Data</title>
</head>
 
<body>
<?php
//including the database connection file
include_once("config.php");
 
if(isset($_POST['Submit'])) {    
    $nazev = $_POST['nazev'];
    $text = $_POST['text'];
    $autor = $_POST['autor'];
        
    // checking empty fields
    if(empty($nazev) ||  empty($autor) || empty($text)) {
        if(empty($$nazev)) {
            echo "<font color='red'>Pole je prázdné.</font><br/>";
        }

        if(empty($autor)) {
            echo "<font color='red'>Pole je prázdné.</font><br/>";
        }
         if(empty($text)) {
            echo "<font color='red'>Pole je prázdné.</font><br/>";
        }
        //link to the previous page
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    } else { 
        // if all the fields are filled (not empty)             
        //insert data to database
        $result = mysqli_query($mysqli, "INSERT INTO clanky(nazev,text,autor) VALUES('$nazev','$text','$autor')");
        
        //display success message
      header("location: index.php");
    }
}
?>
</body>
</html>