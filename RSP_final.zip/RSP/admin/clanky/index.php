<?php
//including the database connection file
include_once("config.php");
include ("../auth.php");
 
//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($mysqli, "SELECT * FROM clanky ORDER BY id DESC"); // using mysqli_query instead
?>
 
<html>
<head>    
  <html lang="cs">
</head>
 
<body>
   <html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>RSP Gumaci</title>
    <link rel="stylesheet" href="style.css">
</head>

<style type="text/css">
    .item{
      width: 100%;
      height: 90vh;
    }
    .text-center{
        margin-top: 20px;
    }
    #tabulka{
        margin-top: 50px;
        width: 80%;
    }
    #nahoru{
        text-align: center;
    }

</style>

<body>
<nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="../../RSP_Gumaci_dokumentace.docx">GUMÁCI VSPJ</a>
          </div>
          <ul class="nav navbar-nav">
            <li class=""><a href="../index.php">ÚVOD</a></li>
            <li><a href="index.php">ČLÁNKY</a></li>
            <li><a href="../kontakt.php">KONTAKT</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
           <li><a><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['username']; ?></a></li>
              <li><a href="../../logout.php"><span class="glyphicon glyphicon-log-in"></span> Odhlášení</a></li>
          </ul>
        </div>
      </nav>




    <table width='80%' border=0 class="table">
        <tr bgcolor='#CCCCCC'>
            <td> Název </td>
            <td>Autor</td>
            <td></td>
	    <td>Update</td>

        </tr>
        <?php

        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['nazev']."</td>";
	     echo "<td>".$res['autor']."</td>";
            echo "<td>".$res['text']."</td>";
	     

            echo "<td><a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Opravdu chcete vymazat článek')\" class='btn btn-danger'>Vymazat</a></td>";
        }
        ?>
    </table>
<br>
<br>
<form method="get" action="addsite.php">
    <button type="submit" class="btn btn-success">Přidat</button>
</form>
</body>
</html>