<?php
// Initialize the session
session_start();

 if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
kill;
}
   else
{
  header("location: ../login.php");
exit();

}

include("auth.php");
// Include config file
require_once "config.php";
 ?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>RSP Gumaci</title>
</head>

<style type="text/css">
    .item{
      width: 100%;
      height: 90vh;
    }
    .text-center{
        margin-top: 20px;
    }
    #tabulka{
        margin-top: 50px;
        width: 80%;
    }
    #nahoru{
        text-align: center;
    }
</style>

<body>

    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="RSP_Gumaci_dokumentace.docx">GUMĂCI VSPJ</a>

            </div>
            <ul class="nav navbar-nav">
                <li class=""><a href="index.php">ÚVOD</a></li>
                <li><a href="clanky/index.php">ČLÁNKY</a></li>
                <li><a href="kontakt.php">KONTAKT</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
             <li><a><span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['username']; ?></a></li>
              <li><a href="../logout.php"><span class="glyphicon glyphicon-log-in"></span> Odhlášení</a></li>
            </ul>
        </div>
    </nav>

    <div class="autonadpis" align="center">
        <h1>KONTAKTY</h1>

        <div class="uvod_text">
            <a href="https://www.facebook.com/vsp.jihlava">FACEBOOK</a>
        </div><br>
        <div class="uvod_text">
            <a href="https://www.vspj.cz/">STRÁNKY ŠKOLY</a>
        </div><br>
        <br />
        <h2>Email:</h2>
        AdministratorGumaci@google.com
        <br />
        AutorGumaci@google.com
        <br />
        UserGumaci@google.com
        <br />
        <h2>Autoři:</h2>
        <br />
        Libor Špejtek
        <br />
        Ondřej Němec
        <br />
        Štěpán Doškář
        <br />
        Jakub Horák
        <br />
        Jan Plašil
        <br />
        <br />
        <br />
        <br />


    </div>


    <div class="container" id="nahoru"><button onclick="window.location.href='#'" class="btn btn-warning">Nahoru</button></div>
    <div class="container-fluid">
        <footer class="text-right">
            <a href="#" data-toggle="tooltip" title="Tvůrce!">&copy; Gumáci 2020</a>
        </footer>
    </div>
    <script>
        $(document).ready(function () {
            $('[data-toggle="popover"]').popover();
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</body>
</html>